# RA6M5 Sensor Backend Server

Backend server hoàn chỉnh để nhận, lưu trữ và cung cấp dữ liệu cảm biến từ board RA6M5 sử dụng NodeJS, Express, MongoDB và WebSocket.

## 🚀 Tính năng

- ✅ Nhận dữ liệu cảm biến từ board RA6M5 qua REST API
- ✅ Lưu trữ dữ liệu vào MongoDB
- ✅ Hỗ trợ gửi 1 bản ghi hoặc nhiều bản ghi (buffer khi reconnect)
- ✅ API query dữ liệu với filter (device, time range, limit)
- ✅ WebSocket (Socket.IO) cho realtime updates
- ✅ Logging chi tiết với Winston
- ✅ Bảo mật cơ bản với Helmet và CORS
- ✅ Validation dữ liệu đầy đủ

## 📁 Cấu trúc thư mục

```
BE/
├── src/
│   ├── config/
│   │   ├── db.js              # Cấu hình MongoDB connection
│   │   └── logger.js          # Cấu hình Winston logger
│   ├── controllers/
│   │   └── sensorController.js # Controllers xử lý requests
│   ├── models/
│   │   └── SensorData.js      # MongoDB schema
│   ├── routes/
│   │   └── sensorRoutes.js    # API routes
│   ├── services/
│   │   └── sensorService.js   # Business logic
│   ├── app.js                 # Express app configuration
│   └── server.js              # Server entry point
├── logs/                      # Log files (auto-generated)
├── .env                       # Environment variables
├── .env.example              # Environment template
├── .gitignore
├── package.json
└── README.md
```

## 🛠️ Công nghệ sử dụng

- **NodeJS** + **Express**: Web framework
- **MongoDB** + **Mongoose**: Database
- **Socket.IO**: WebSocket cho realtime
- **Winston**: Logging
- **Helmet**: Bảo mật HTTP headers
- **CORS**: Cross-Origin Resource Sharing
- **dotenv**: Environment variables

## 📋 Yêu cầu hệ thống

- Node.js >= 14.x
- MongoDB >= 4.x (local hoặc cloud)
- npm hoặc yarn

## 🔧 Cài đặt

### 1. Clone và cài đặt dependencies

```bash
cd BE
npm install
```

### 2. Cấu hình môi trường

Tạo file `.env` từ `.env.example`:

```bash
cp .env.example .env
```

Chỉnh sửa file `.env`:

```env
NODE_ENV=development
PORT=3000
MONGO_URI=mongodb://localhost:27017/ra6m5db
FRONTEND_URL=http://localhost:5173
LOG_LEVEL=info
```

### 3. Khởi động MongoDB

**Trên Windows:**

```bash
# Nếu MongoDB đã cài đặt như service
net start MongoDB

# Hoặc chạy trực tiếp
mongod --dbpath="C:\data\db"
```

**Trên Linux/Mac:**

```bash
sudo systemctl start mongod
# hoặc
brew services start mongodb-community
```

### 4. Chạy server

**Development mode (với nodemon):**

```bash
npm run dev
```

**Production mode:**

```bash
npm start
```

Server sẽ chạy tại: `http://localhost:3000`

## 📡 API Endpoints

### 1. Health Check

```
GET /health
```

**Response:**

```json
{
  "success": true,
  "message": "Server is running",
  "timestamp": "2025-12-07T10:30:00.000Z"
}
```

### 2. Tạo dữ liệu cảm biến (1 bản ghi)

```
POST /api/sensor-data
Content-Type: application/json
```

**Body:**

```json
{
  "timestamp": "2025-08-21T14:30:05Z",
  "device": "ck-ra6m5-01",
  "sensor": "zmod4410",
  "tvoc": 220,
  "iaq": 95
}
```

**Response:**

```json
{
  "success": true,
  "message": "Successfully saved 1 record(s)",
  "count": 1,
  "data": {
    "_id": "...",
    "timestamp": "2025-08-21T14:30:05.000Z",
    "device": "ck-ra6m5-01",
    "sensor": "zmod4410",
    "tvoc": 220,
    "iaq": 95,
    "createdAt": "...",
    "updatedAt": "..."
  }
}
```

### 3. Tạo dữ liệu cảm biến (nhiều bản ghi)

```
POST /api/sensor-data
Content-Type: application/json
```

**Body:**

```json
[
  {
    "timestamp": "2025-08-21T14:30:05Z",
    "device": "ck-ra6m5-01",
    "sensor": "zmod4410",
    "tvoc": 220,
    "iaq": 95
  },
  {
    "timestamp": "2025-08-21T14:31:05Z",
    "device": "ck-ra6m5-01",
    "sensor": "zmod4410",
    "tvoc": 225,
    "iaq": 97
  }
]
```

### 4. Lấy tất cả dữ liệu (có filter)

```
GET /api/sensor-data?device=ck-ra6m5-01&limit=100&from=2025-08-21&to=2025-08-30
```

**Query Parameters:**

- `device` (optional): Lọc theo tên thiết bị
- `limit` (optional): Số lượng bản ghi (default: 100)
- `from` (optional): Từ ngày (format: YYYY-MM-DD)
- `to` (optional): Đến ngày (format: YYYY-MM-DD)

**Response:**

```json
{
  "success": true,
  "count": 2,
  "data": [...]
}
```

### 5. Lấy bản ghi mới nhất

```
GET /api/sensor-data/latest
```

**Response:**

```json
{
  "success": true,
  "data": {
    "_id": "...",
    "timestamp": "2025-08-21T14:31:05.000Z",
    "device": "ck-ra6m5-01",
    "sensor": "zmod4410",
    "tvoc": 225,
    "iaq": 97,
    "createdAt": "...",
    "updatedAt": "..."
  }
}
```

## 🔌 WebSocket Events

Server sử dụng Socket.IO để push realtime data đến clients.

### Client connection

```javascript
import { io } from "socket.io-client";

const socket = io("http://localhost:3000");

// Lắng nghe dữ liệu mới
socket.on("newData", (data) => {
  console.log("New sensor data:", data);
});

// Request dữ liệu mới nhất
socket.emit("requestLatestData");

socket.on("latestData", (data) => {
  console.log("Latest data:", data);
});
```

### Events

- **`newData`**: Server emit khi có dữ liệu mới được lưu
- **`requestLatestData`**: Client emit để request dữ liệu mới nhất
- **`latestData`**: Server response với dữ liệu mới nhất

## 📊 Logging

Server log được lưu tại:

- `logs/combined.log`: Tất cả logs
- `logs/error.log`: Chỉ errors

Format log cho sensor data:

```
[2025-08-21T14:30:05.000Z] dev=ck-ra6m5-01 sensor=zmod4410 tvoc=220 iaq=95
```

## 🧪 Test API với cURL

### Gửi 1 bản ghi:

```bash
curl -X POST http://localhost:3000/api/sensor-data \
  -H "Content-Type: application/json" \
  -d '{
    "timestamp": "2025-08-21T14:30:05Z",
    "device": "ck-ra6m5-01",
    "sensor": "zmod4410",
    "tvoc": 220,
    "iaq": 95
  }'
```

### Gửi nhiều bản ghi:

```bash
curl -X POST http://localhost:3000/api/sensor-data \
  -H "Content-Type: application/json" \
  -d '[
    {
      "timestamp": "2025-08-21T14:30:05Z",
      "device": "ck-ra6m5-01",
      "sensor": "zmod4410",
      "tvoc": 220,
      "iaq": 95
    },
    {
      "timestamp": "2025-08-21T14:31:05Z",
      "device": "ck-ra6m5-01",
      "sensor": "zmod4410",
      "tvoc": 225,
      "iaq": 97
    }
  ]'
```

### Lấy dữ liệu:

```bash
# Tất cả dữ liệu
curl http://localhost:3000/api/sensor-data

# Với filter
curl "http://localhost:3000/api/sensor-data?device=ck-ra6m5-01&limit=10"

# Dữ liệu mới nhất
curl http://localhost:3000/api/sensor-data/latest
```

## 🔒 Bảo mật

- ✅ Helmet.js cho HTTP headers security
- ✅ CORS được cấu hình cho frontend
- ✅ Body size limit: 1MB
- ✅ Content-Type validation cho POST requests
- ✅ Input validation với Mongoose schema
- ✅ Error handling toàn diện

## 🐛 Troubleshooting

### Lỗi kết nối MongoDB

```
Error: connect ECONNREFUSED 127.0.0.1:27017
```

**Giải pháp:**

- Kiểm tra MongoDB đang chạy: `mongod --version`
- Khởi động MongoDB service
- Kiểm tra MONGO_URI trong file `.env`

### Port đã được sử dụng

```
Error: listen EADDRINUSE: address already in use :::3000
```

**Giải pháp:**

- Thay đổi PORT trong `.env`
- Hoặc kill process đang dùng port 3000

### CORS errors từ frontend

**Giải pháp:**

- Kiểm tra FRONTEND_URL trong `.env` match với URL frontend
- Đảm bảo frontend gửi requests đúng origin

## 📝 License

ISC

## 👨‍💻 Author

RA6M5 Sensor Project Team

---

**Lưu ý:** Đây là phiên bản development. Cho production, cần thêm:

- Authentication/Authorization
- Rate limiting
- Database backup strategy
- Monitoring và alerting
- Load balancing
- SSL/TLS certificates
