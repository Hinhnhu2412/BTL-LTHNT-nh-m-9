const mongoose = require("mongoose");
const logger = require("./logger");

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      // Mongoose 6+ không cần useNewUrlParser và useUnifiedTopology
    });

    logger.info(`MongoDB Connected: ${conn.connection.host}`);

    // Log khi kết nối bị đóng
    mongoose.connection.on("disconnected", () => {
      logger.warn("MongoDB disconnected");
    });

    // Log khi có lỗi sau khi kết nối thành công
    mongoose.connection.on("error", (err) => {
      logger.error(`MongoDB connection error: ${err}`);
    });
  } catch (error) {
    logger.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
