const SensorData = require("../models/SensorData");
const logger = require("../config/logger");

class SensorService {
  /**
   * Lưu dữ liệu cảm biến (1 bản ghi hoặc nhiều bản ghi)
   * @param {Object|Array} data - Dữ liệu cảm biến
   * @returns {Promise<Object>}
   */
  async saveSensorData(data) {
    try {
      // Kiểm tra nếu là array
      if (Array.isArray(data)) {
        // Validate từng phần tử
        this.validateDataArray(data);

        // Insert nhiều bản ghi
        const savedData = await SensorData.insertMany(data);

        // Log từng bản ghi
        savedData.forEach((record) => {
          this.logSensorData(record);
        });

        logger.info(`Saved ${savedData.length} sensor records (bulk insert)`);

        return {
          success: true,
          count: savedData.length,
          data: savedData,
        };
      } else {
        // Validate single object
        this.validateDataObject(data);

        // Lưu 1 bản ghi
        const sensorData = new SensorData(data);
        const savedData = await sensorData.save();

        // Log bản ghi
        this.logSensorData(savedData);

        return {
          success: true,
          count: 1,
          data: savedData,
        };
      }
    } catch (error) {
      logger.error(`Error saving sensor data: ${error.message}`);
      throw error;
    }
  }

  /**
   * Lấy dữ liệu với filter
   * @param {Object} filters - {device, limit, from, to}
   * @returns {Promise<Array>}
   */
  async getSensorData(filters = {}) {
    try {
      const query = {};

      // Filter theo device
      if (filters.device) {
        query.device = filters.device;
      }

      // Filter theo thời gian
      if (filters.from || filters.to) {
        query.timestamp = {};

        if (filters.from) {
          query.timestamp.$gte = new Date(filters.from);
        }

        if (filters.to) {
          // Thêm 1 ngày để bao gồm cả ngày to
          const toDate = new Date(filters.to);
          toDate.setDate(toDate.getDate() + 1);
          query.timestamp.$lt = toDate;
        }
      }

      // Giới hạn số lượng bản ghi
      const limit = parseInt(filters.limit) || 100;

      const data = await SensorData.find(query)
        .sort({ timestamp: -1 })
        .limit(limit);

      logger.info(
        `Retrieved ${data.length} sensor records with filters: ${JSON.stringify(
          filters
        )}`
      );

      return data;
    } catch (error) {
      logger.error(`Error getting sensor data: ${error.message}`);
      throw error;
    }
  }

  /**
   * Lấy bản ghi mới nhất
   * @returns {Promise<Object|null>}
   */
  async getLatestSensorData() {
    try {
      const data = await SensorData.findOne().sort({ timestamp: -1 });

      if (data) {
        logger.info(`Retrieved latest sensor record: ${data._id}`);
      } else {
        logger.info("No sensor data found");
      }

      return data;
    } catch (error) {
      logger.error(`Error getting latest sensor data: ${error.message}`);
      throw error;
    }
  }

  /**
   * Validate single data object
   */
  validateDataObject(data) {
    if (!data || typeof data !== "object") {
      throw new Error("Invalid data format");
    }

    const requiredFields = ["device", "sensor", "tvoc", "iaq"];
    const missingFields = requiredFields.filter((field) => !(field in data));

    if (missingFields.length > 0) {
      throw new Error(`Missing required fields: ${missingFields.join(", ")}`);
    }

    // Validate number fields
    if (typeof data.tvoc !== "number" || data.tvoc < 0) {
      throw new Error("TVOC must be a non-negative number");
    }

    if (typeof data.iaq !== "number" || data.iaq < 0) {
      throw new Error("IAQ must be a non-negative number");
    }
  }

  /**
   * Validate array of data objects
   */
  validateDataArray(dataArray) {
    if (!Array.isArray(dataArray) || dataArray.length === 0) {
      throw new Error("Data must be a non-empty array");
    }

    dataArray.forEach((item, index) => {
      try {
        this.validateDataObject(item);
      } catch (error) {
        throw new Error(`Invalid data at index ${index}: ${error.message}`);
      }
    });
  }

  /**
   * Log sensor data theo format yêu cầu
   * Format: [timestamp] dev=device sensor=sensor tvoc=xxx iaq=xxx
   */
  logSensorData(data) {
    const timestamp = data.timestamp.toISOString();
    const logMessage = `dev=${data.device} sensor=${data.sensor} tvoc=${data.tvoc} iaq=${data.iaq}`;
    logger.info(`[${timestamp}] ${logMessage}`);
  }
}

module.exports = new SensorService();
