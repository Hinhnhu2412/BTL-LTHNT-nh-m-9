const express = require("express");
const router = express.Router();
const sensorController = require("../controllers/sensorController");

// POST /api/sensor-data - Tạo dữ liệu cảm biến mới
router.post("/", sensorController.createSensorData);

// GET /api/sensor-data - Lấy dữ liệu với filter
router.get("/", sensorController.getSensorData);

// GET /api/sensor-data/latest - Lấy bản ghi mới nhất
router.get("/latest", sensorController.getLatestSensorData);

module.exports = router;
