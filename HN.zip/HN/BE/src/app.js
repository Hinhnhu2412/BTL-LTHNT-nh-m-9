const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const sensorRoutes = require("./routes/sensorRoutes");
const logger = require("./config/logger");

const app = express();

// Middleware bảo mật
app.use(helmet());

// CORS - Cho phép cả frontend React và board RA6M5
app.use(
  cors({
    origin: function (origin, callback) {
      // Cho phép requests không có origin (như từ board RA6M5, Postman, curl)
      if (!origin) return callback(null, true);

      // Cho phép frontend URL từ env
      const allowedOrigins = [
        process.env.FRONTEND_URL || "http://localhost:5173",
        "http://localhost:3000", // Cho phép test local
      ];

      if (
        allowedOrigins.indexOf(origin) !== -1 ||
        process.env.NODE_ENV === "development"
      ) {
        callback(null, true);
      } else {
        callback(null, true); // Hoặc để true để cho phép tất cả origins
      }
    },
    credentials: true,
  })
);

// Body parser với giới hạn 1MB
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

// Middleware kiểm tra Content-Type cho POST requests
app.use("/api/sensor-data", (req, res, next) => {
  if (req.method === "POST") {
    const contentType = req.get("Content-Type");
    if (!contentType || !contentType.includes("application/json")) {
      logger.warn(`Invalid Content-Type: ${contentType}`);
      return res.status(415).json({
        success: false,
        message: "Content-Type must be application/json",
      });
    }
  }
  next();
});

// Middleware để attach socket.io vào request
app.use((req, res, next) => {
  req.io = app.get("io");
  next();
});

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path} - IP: ${req.ip}`);
  next();
});

// Routes
app.use("/api/sensor-data", sensorRoutes);

// Health check endpoint
app.get("/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Server is running",
    timestamp: new Date().toISOString(),
  });
});

// Root endpoint
app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "RA6M5 Sensor Backend API",
    version: "1.0.0",
    endpoints: {
      health: "/health",
      sensorData: {
        create: "POST /api/sensor-data",
        getAll: "GET /api/sensor-data",
        getLatest: "GET /api/sensor-data/latest",
      },
    },
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
  });
});

// Global error handler
app.use((err, req, res, next) => {
  logger.error(`Unhandled error: ${err.message}`, { stack: err.stack });

  res.status(err.status || 500).json({
    success: false,
    message: err.message || "Internal server error",
  });
});

module.exports = app;
