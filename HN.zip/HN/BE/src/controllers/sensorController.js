const sensorService = require("../services/sensorService");
const logger = require("../config/logger");

/**
 * @desc    Tạo dữ liệu cảm biến mới (1 hoặc nhiều bản ghi)
 * @route   POST /api/sensor-data
 * @access  Public
 */
exports.createSensorData = async (req, res) => {
  try {
    const result = await sensorService.saveSensorData(req.body);

    // Emit event qua WebSocket nếu có
    if (req.io) {
      req.io.emit("newData", result.data);
    }

    res.status(201).json({
      success: true,
      message: `Successfully saved ${result.count} record(s)`,
      count: result.count,
      data: result.data,
    });
  } catch (error) {
    logger.error(`Controller error: ${error.message}`);

    // Xử lý validation errors
    if (error.name === "ValidationError") {
      return res.status(400).json({
        success: false,
        message: "Validation error",
        errors: Object.values(error.errors).map((err) => err.message),
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || "Error saving sensor data",
    });
  }
};

/**
 * @desc    Lấy dữ liệu cảm biến với filter
 * @route   GET /api/sensor-data
 * @access  Public
 */
exports.getSensorData = async (req, res) => {
  try {
    const filters = {
      device: req.query.device,
      limit: req.query.limit,
      from: req.query.from,
      to: req.query.to,
    };

    const data = await sensorService.getSensorData(filters);

    res.status(200).json({
      success: true,
      count: data.length,
      data: data,
    });
  } catch (error) {
    logger.error(`Controller error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: error.message || "Error retrieving sensor data",
    });
  }
};

/**
 * @desc    Lấy bản ghi mới nhất
 * @route   GET /api/sensor-data/latest
 * @access  Public
 */
exports.getLatestSensorData = async (req, res) => {
  try {
    const data = await sensorService.getLatestSensorData();

    if (!data) {
      return res.status(404).json({
        success: false,
        message: "No sensor data found",
      });
    }

    res.status(200).json({
      success: true,
      data: data,
    });
  } catch (error) {
    logger.error(`Controller error: ${error.message}`);
    res.status(500).json({
      success: false,
      message: error.message || "Error retrieving latest sensor data",
    });
  }
};
