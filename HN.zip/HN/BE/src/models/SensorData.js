const mongoose = require("mongoose");

const sensorDataSchema = new mongoose.Schema(
  {
    timestamp: {
      type: Date,
      required: [true, "Timestamp is required"],
      default: Date.now,
    },
    device: {
      type: String,
      required: [true, "Device name is required"],
      trim: true,
      index: true,
    },
    sensor: {
      type: String,
      required: [true, "Sensor type is required"],
      trim: true,
    },
    tvoc: {
      type: Number,
      required: [true, "TVOC value is required"],
      min: [0, "TVOC cannot be negative"],
    },
    iaq: {
      type: Number,
      required: [true, "IAQ value is required"],
      min: [0, "IAQ cannot be negative"],
    },
  },
  {
    timestamps: true, // Thêm createdAt và updatedAt
    versionKey: false,
  }
);

// Index để tối ưu query
sensorDataSchema.index({ timestamp: -1 });
sensorDataSchema.index({ device: 1, timestamp: -1 });

const SensorData = mongoose.model("SensorData", sensorDataSchema);

module.exports = SensorData;
