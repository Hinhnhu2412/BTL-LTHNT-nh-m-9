require("dotenv").config();
const http = require("http");
const { Server } = require("socket.io");
const app = require("./app");
const connectDB = require("./config/db");
const logger = require("./config/logger");

// Kết nối MongoDB
connectDB();

// Tạo HTTP server
const server = http.createServer(app);

// Khởi tạo Socket.IO
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    methods: ["GET", "POST"],
    credentials: true,
  },
});

// Lưu io instance vào app để sử dụng trong controllers
app.set("io", io);

// Socket.IO connection handler
io.on("connection", (socket) => {
  logger.info(`Client connected: ${socket.id}`);

  socket.on("disconnect", () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });

  // Có thể thêm các event handlers khác nếu cần
  socket.on("requestLatestData", async () => {
    try {
      const sensorService = require("./services/sensorService");
      const latestData = await sensorService.getLatestSensorData();
      socket.emit("latestData", latestData);
    } catch (error) {
      logger.error(`Error sending latest data: ${error.message}`);
    }
  });
});

// Lấy port từ environment hoặc dùng 3000
const PORT = process.env.PORT || 3000;

// Start server
server.listen(PORT, () => {
  logger.info(`Server is running on port ${PORT}`);
  logger.info(`Environment: ${process.env.NODE_ENV || "development"}`);
  logger.info(`WebSocket enabled on port ${PORT}`);
});

// Xử lý graceful shutdown
process.on("SIGTERM", () => {
  logger.info("SIGTERM signal received: closing HTTP server");
  server.close(() => {
    logger.info("HTTP server closed");
    process.exit(0);
  });
});

process.on("SIGINT", () => {
  logger.info("SIGINT signal received: closing HTTP server");
  server.close(() => {
    logger.info("HTTP server closed");
    process.exit(0);
  });
});

// Xử lý unhandled rejections
process.on("unhandledRejection", (err) => {
  logger.error(`Unhandled Rejection: ${err.message}`, { stack: err.stack });
  server.close(() => process.exit(1));
});
