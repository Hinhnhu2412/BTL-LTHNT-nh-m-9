import { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import StatsCard from "../components/StatsCard";
import SensorTable from "../components/SensorTable";
import RealtimeChart from "../components/RealtimeChart";
import { sensorAPI } from "../api/sensorApi";
import { useSocket } from "../hooks/useSocket";
import { RefreshCw, Wifi, WifiOff } from "lucide-react";

// Main Dashboard page component
// Orchestrates data fetching and realtime updates via Socket.IO
const Dashboard = () => {
  const [sensorData, setSensorData] = useState([]);
  const [stats, setStats] = useState({
    totalRecords: 0,
    latestIAQ: 0,
    latestTVOC: 0,
  });
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  // Socket.IO hook để nhận realtime updates
  const { isConnected, newData, error } = useSocket();

  // Fetch initial data on component mount
  const fetchData = async () => {
    try {
      setLoading(true);

      // Lấy dữ liệu từ API
      const response = await sensorAPI.getAllData({ limit: 50 });
      setSensorData(response.data || []);

      // Lấy thống kê
      const statsData = await sensorAPI.getStats();
      setStats(statsData);

      setLastUpdate(new Date());
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    fetchData();
  }, []);

  // Xử lý khi nhận dữ liệu mới từ Socket.IO
  useEffect(() => {
    if (newData) {
      console.log("🔥 New data received via socket:", newData);

      // Refresh toàn bộ data để có dữ liệu mới nhất
      fetchData();
    }
  }, [newData]);

  // Manual refresh handler
  const handleManualRefresh = () => {
    fetchData();
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <RefreshCw className="h-12 w-12 text-cyan-500 animate-spin mx-auto mb-4" />
            <p className="text-gray-600">Loading sensor data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation Bar */}
      <Navbar />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header with Status and Refresh Button */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">
              Dashboard Overview
            </h2>
            <div className="flex items-center space-x-4 mt-1">
              <p className="text-sm text-gray-600">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </p>
              {/* Socket Connection Status */}
              <div className="flex items-center space-x-1">
                {isConnected ? (
                  <>
                    <Wifi className="h-4 w-4 text-green-500" />
                    <span className="text-xs text-green-600 font-medium">
                      Realtime Connected
                    </span>
                  </>
                ) : (
                  <>
                    <WifiOff className="h-4 w-4 text-red-500" />
                    <span className="text-xs text-red-600 font-medium">
                      {error ? `Error: ${error}` : "Disconnected"}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
          <button
            onClick={handleManualRefresh}
            className="flex items-center space-x-2 px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors duration-200 shadow-md"
          >
            <RefreshCw className="h-4 w-4" />
            <span>Refresh</span>
          </button>
        </div>

        {/* Statistics Cards */}
        <StatsCard
          totalRecords={stats.totalRecords}
          latestIAQ={stats.latestIAQ}
          latestTVOC={stats.latestTVOC}
        />

        {/* Chart Section */}
        <div className="mb-6">
          <RealtimeChart data={sensorData} />
        </div>

        {/* Data Table Section */}
        <div>
          <SensorTable data={sensorData} />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-sm text-gray-600">
            <p>RA6M5 Monitoring System • Real-time Air Quality Monitoring</p>
            <p className="mt-1 text-xs text-gray-500">
              Realtime updates via WebSocket • Showing last 50 records
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
