import { TrendingUp, Wind, Database } from 'lucide-react';

// Helper function to determine IAQ level and color
// IAQ Index: 0-50 Excellent, 51-100 Good, 101-150 Moderate, 151-200 Poor, 201+ Very Poor
const getIAQStatus = (iaq) => {
  if (iaq <= 50) {
    return { level: 'Excellent', color: 'bg-green-500', textColor: 'text-green-500', bgLight: 'bg-green-50' };
  } else if (iaq <= 100) {
    return { level: 'Good', color: 'bg-blue-500', textColor: 'text-blue-500', bgLight: 'bg-blue-50' };
  } else if (iaq <= 150) {
    return { level: 'Moderate', color: 'bg-yellow-500', textColor: 'text-yellow-600', bgLight: 'bg-yellow-50' };
  } else if (iaq <= 200) {
    return { level: 'Poor', color: 'bg-orange-500', textColor: 'text-orange-600', bgLight: 'bg-orange-50' };
  } else {
    return { level: 'Very Poor', color: 'bg-red-500', textColor: 'text-red-600', bgLight: 'bg-red-50' };
  }
};

// Helper function to determine TVOC level and color
// TVOC (ppb): 0-65 Excellent, 66-220 Good, 221-660 Moderate, 661-2200 Poor, 2201+ Very Poor
const getTVOCStatus = (tvoc) => {
  if (tvoc <= 65) {
    return { level: 'Excellent', color: 'bg-green-500', textColor: 'text-green-500', bgLight: 'bg-green-50' };
  } else if (tvoc <= 220) {
    return { level: 'Good', color: 'bg-blue-500', textColor: 'text-blue-500', bgLight: 'bg-blue-50' };
  } else if (tvoc <= 660) {
    return { level: 'Moderate', color: 'bg-yellow-500', textColor: 'text-yellow-600', bgLight: 'bg-yellow-50' };
  } else if (tvoc <= 2200) {
    return { level: 'Poor', color: 'bg-orange-500', textColor: 'text-orange-600', bgLight: 'bg-orange-50' };
  } else {
    return { level: 'Very Poor', color: 'bg-red-500', textColor: 'text-red-600', bgLight: 'bg-red-50' };
  }
};

// StatsCard component to display key metrics
// Props: totalRecords, latestIAQ, latestTVOC
const StatsCard = ({ totalRecords, latestIAQ, latestTVOC }) => {
  const iaqStatus = getIAQStatus(latestIAQ);
  const tvocStatus = getTVOCStatus(latestTVOC);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      {/* Total Records Card */}
      <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600 mb-1">Total Records</p>
            <p className="text-3xl font-bold text-slate-800">{totalRecords}</p>
            <p className="text-xs text-gray-500 mt-1">All time data points</p>
          </div>
          <div className="bg-slate-100 p-3 rounded-lg">
            <Database className="h-8 w-8 text-slate-600" />
          </div>
        </div>
      </div>

      {/* IAQ Card */}
      <div className={`bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 p-6 border-l-4 ${iaqStatus.color}`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600 mb-1">IAQ Index</p>
            <p className={`text-3xl font-bold ${iaqStatus.textColor}`}>{latestIAQ}</p>
            <div className="flex items-center mt-1">
              <span className={`text-xs font-semibold px-2 py-1 rounded ${iaqStatus.bgLight} ${iaqStatus.textColor}`}>
                {iaqStatus.level}
              </span>
            </div>
          </div>
          <div className={`${iaqStatus.bgLight} p-3 rounded-lg`}>
            <TrendingUp className={`h-8 w-8 ${iaqStatus.textColor}`} />
          </div>
        </div>
      </div>

      {/* TVOC Card */}
      <div className={`bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 p-6 border-l-4 ${tvocStatus.color}`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600 mb-1">TVOC Level</p>
            <p className={`text-3xl font-bold ${tvocStatus.textColor}`}>{latestTVOC} <span className="text-lg">ppb</span></p>
            <div className="flex items-center mt-1">
              <span className={`text-xs font-semibold px-2 py-1 rounded ${tvocStatus.bgLight} ${tvocStatus.textColor}`}>
                {tvocStatus.level}
              </span>
            </div>
          </div>
          <div className={`${tvocStatus.bgLight} p-3 rounded-lg`}>
            <Wind className={`h-8 w-8 ${tvocStatus.textColor}`} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsCard;
