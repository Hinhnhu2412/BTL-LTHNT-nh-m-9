import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

// RealtimeChart component to display TVOC and IAQ trends over time
// Uses recharts library for interactive, responsive charts
const RealtimeChart = ({ data }) => {
  // Prepare chart data - take last 20 points for better visualization
  const chartData = data.slice(-20).map((item) => {
    // Xử lý timestamp - có thể là ISO format hoặc string
    let timeLabel = "";
    if (item.timestamp) {
      try {
        // Nếu timestamp là ISO string (2025-12-07T14:30:05.000Z)
        const date = new Date(item.timestamp);
        timeLabel = date.toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        });
      } catch (error) {
        // Fallback nếu parse lỗi
        timeLabel = String(item.timestamp).substring(0, 8) || "N/A";
      }
    }

    return {
      time: timeLabel,
      TVOC: item.tvoc || 0,
      IAQ: item.iaq || 0,
    };
  });

  // Custom tooltip for better data display
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white px-4 py-3 rounded-lg shadow-lg border border-gray-200">
          <p className="text-sm font-semibold text-gray-800 mb-2">{`Time: ${payload[0].payload.time}`}</p>
          <p className="text-sm text-cyan-600">
            TVOC: <span className="font-bold">{payload[0].value} ppb</span>
          </p>
          <p className="text-sm text-teal-600">
            IAQ: <span className="font-bold">{payload[1].value}</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      {/* Chart Header */}
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-slate-800">
          Real-time Sensor Trends
        </h2>
        <p className="text-sm text-gray-600">TVOC and IAQ values over time</p>
      </div>

      {/* Chart Container */}
      <div className="w-full h-80">
        {chartData.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500">
            No data available for chart
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis
                dataKey="time"
                stroke="#6b7280"
                style={{ fontSize: "12px" }}
                angle={-45}
                textAnchor="end"
                height={60}
              />
              <YAxis stroke="#6b7280" style={{ fontSize: "12px" }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ paddingTop: "10px" }} iconType="line" />
              <Line
                type="monotone"
                dataKey="TVOC"
                stroke="#06b6d4"
                strokeWidth={2}
                dot={{ fill: "#06b6d4", r: 4 }}
                activeDot={{ r: 6 }}
                name="TVOC (ppb)"
              />
              <Line
                type="monotone"
                dataKey="IAQ"
                stroke="#14b8a6"
                strokeWidth={2}
                dot={{ fill: "#14b8a6", r: 4 }}
                activeDot={{ r: 6 }}
                name="IAQ Index"
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Chart Legend Info */}
      <div className="mt-4 flex flex-wrap gap-4 text-xs text-gray-600">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-cyan-500 rounded-full mr-2"></div>
          <span>TVOC: Total Volatile Organic Compounds (ppb)</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-teal-500 rounded-full mr-2"></div>
          <span>IAQ: Indoor Air Quality Index</span>
        </div>
      </div>
    </div>
  );
};

export default RealtimeChart;
