// SensorTable component to display sensor log data in a scrollable table
// Shows: Time, Device, Sensor, TVOC, IAQ with color-coded values

// Helper function to get badge color based on IAQ value
const getIAQBadgeColor = (iaq) => {
  if (iaq <= 50) return "bg-green-100 text-green-800";
  if (iaq <= 100) return "bg-blue-100 text-blue-800";
  if (iaq <= 150) return "bg-yellow-100 text-yellow-800";
  if (iaq <= 200) return "bg-orange-100 text-orange-800";
  return "bg-red-100 text-red-800";
};

// Helper function to get badge color based on TVOC value
const getTVOCBadgeColor = (tvoc) => {
  if (tvoc <= 65) return "bg-green-100 text-green-800";
  if (tvoc <= 220) return "bg-blue-100 text-blue-800";
  if (tvoc <= 660) return "bg-yellow-100 text-yellow-800";
  if (tvoc <= 2200) return "bg-orange-100 text-orange-800";
  return "bg-red-100 text-red-800";
};

const SensorTable = ({ data }) => {
  // Reverse data to show newest first
  const reversedData = [...data].reverse();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {/* Table Header */}
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 px-6 py-4">
        <h2 className="text-lg font-semibold text-white">Sensor Data Log</h2>
        <p className="text-sm text-gray-300">
          Real-time monitoring data from RA6M5 devices
        </p>
      </div>

      {/* Scrollable Table Container */}
      <div className="overflow-x-auto">
        <div className="max-h-96 overflow-y-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Timestamp
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Device
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Sensor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  TVOC
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  IAQ
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {reversedData.length === 0 ? (
                <tr>
                  <td
                    colSpan="5"
                    className="px-6 py-8 text-center text-gray-500"
                  >
                    No data available
                  </td>
                </tr>
              ) : (
                reversedData.map((item, index) => (
                  <tr
                    key={index}
                    className="hover:bg-gray-50 transition-colors duration-150"
                  >
                    {/* Timestamp */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-cyan-500 rounded-full mr-2"></div>
                        {item.timestamp
                          ? new Date(item.timestamp).toLocaleString("en-US", {
                              year: "numeric",
                              month: "2-digit",
                              day: "2-digit",
                              hour: "2-digit",
                              minute: "2-digit",
                              second: "2-digit",
                              hour12: false,
                            })
                          : "N/A"}
                      </div>
                    </td>

                    {/* Device */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm font-medium text-slate-700">
                        {item.device}
                      </span>
                    </td>

                    {/* Sensor */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-slate-100 text-slate-700">
                        {item.sensor}
                      </span>
                    </td>

                    {/* TVOC */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${getTVOCBadgeColor(
                          item.tvoc
                        )}`}
                      >
                        {item.tvoc} ppb
                      </span>
                    </td>

                    {/* IAQ */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${getIAQBadgeColor(
                          item.iaq
                        )}`}
                      >
                        {item.iaq}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Table Footer */}
      <div className="bg-gray-50 px-6 py-3 border-t border-gray-200">
        <p className="text-xs text-gray-600">
          Showing {reversedData.length} records • Updated every 3 seconds
        </p>
      </div>
    </div>
  );
};

export default SensorTable;
