import { Activity } from 'lucide-react';

// Navbar component for the RA6M5 Monitoring dashboard
// Displays logo and system title with a professional dark blue theme
const Navbar = () => {
  return (
    <nav className="bg-gradient-to-r from-slate-800 to-slate-900 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-cyan-500 p-2 rounded-lg shadow-md">
              <Activity className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">
                RA6M5 Monitoring
              </h1>
              <p className="text-xs text-cyan-300">
                Real-time Sensor Dashboard
              </p>
            </div>
          </div>

          {/* Status Indicator */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="ml-2 text-sm text-gray-300">Live</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
