import { useState, useEffect, useCallback } from "react";
import socketService from "../api/socket";

/**
 * Custom Hook để sử dụng Socket.IO trong React components
 * @returns {Object} { isConnected, newData, error }
 */
export const useSocket = () => {
  const [isConnected, setIsConnected] = useState(socketService.isConnected());
  const [newData, setNewData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Kết nối socket khi component mount
    socketService.connect();

    // Handler cho connection events
    const handleConnect = () => {
      setIsConnected(true);
      setError(null);
      console.log("Socket connected");
    };

    const handleDisconnect = () => {
      setIsConnected(false);
      console.log("Socket disconnected");
    };

    const handleConnectError = (err) => {
      setError(err.message);
      setIsConnected(false);
      console.error("Socket connection error:", err);
    };

    // Handler cho newData event
    const handleNewData = (data) => {
      console.log("📥 Received new data:", data);
      setNewData(data);
    };

    // Đăng ký event listeners
    socketService.socket.on("connect", handleConnect);
    socketService.socket.on("disconnect", handleDisconnect);
    socketService.socket.on("connect_error", handleConnectError);
    socketService.onNewData(handleNewData);

    // Cleanup khi component unmount
    return () => {
      socketService.socket.off("connect", handleConnect);
      socketService.socket.off("disconnect", handleDisconnect);
      socketService.socket.off("connect_error", handleConnectError);
      socketService.offNewData(handleNewData);
    };
  }, []);

  // Function để request latest data
  const requestLatestData = useCallback(() => {
    socketService.requestLatestData();
  }, []);

  return {
    isConnected,
    newData,
    error,
    requestLatestData,
  };
};

export default useSocket;
