import { io } from "socket.io-client";

// Lấy socket URL từ environment
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || "http://localhost:3000";

// Tạo socket instance
const socket = io(SOCKET_URL, {
  transports: ["websocket", "polling"],
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionAttempts: 5,
});

// Socket event listeners
socket.on("connect", () => {
  console.log("✅ Connected to server:", socket.id);
});

socket.on("disconnect", (reason) => {
  console.log("❌ Disconnected from server:", reason);
});

socket.on("connect_error", (error) => {
  console.error("🔴 Connection error:", error.message);
});

socket.on("reconnect", (attemptNumber) => {
  console.log("🔄 Reconnected after", attemptNumber, "attempts");
});

// Export socket instance và helper functions
export const socketService = {
  // Socket instance
  socket,

  /**
   * Lắng nghe event nhận dữ liệu mới
   * @param {Function} callback - Hàm xử lý khi nhận dữ liệu mới
   */
  onNewData: (callback) => {
    socket.on("newData", callback);
  },

  /**
   * Hủy lắng nghe event newData
   * @param {Function} callback - Hàm callback đã đăng ký
   */
  offNewData: (callback) => {
    socket.off("newData", callback);
  },

  /**
   * Request dữ liệu mới nhất từ server
   */
  requestLatestData: () => {
    socket.emit("requestLatestData");
  },

  /**
   * Lắng nghe event nhận dữ liệu mới nhất
   * @param {Function} callback - Hàm xử lý khi nhận dữ liệu
   */
  onLatestData: (callback) => {
    socket.on("latestData", callback);
  },

  /**
   * Hủy lắng nghe event latestData
   * @param {Function} callback - Hàm callback đã đăng ký
   */
  offLatestData: (callback) => {
    socket.off("latestData", callback);
  },

  /**
   * Ngắt kết nối socket
   */
  disconnect: () => {
    if (socket.connected) {
      socket.disconnect();
    }
  },

  /**
   * Kết nối lại socket
   */
  connect: () => {
    if (!socket.connected) {
      socket.connect();
    }
  },

  /**
   * Kiểm tra trạng thái kết nối
   * @returns {Boolean}
   */
  isConnected: () => {
    return socket.connected;
  },
};

export default socketService;
