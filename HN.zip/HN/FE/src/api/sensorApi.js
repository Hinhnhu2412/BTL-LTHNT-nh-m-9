import axios from "axios";

// Lấy API URL từ environment variables
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

// Tạo axios instance
const axiosInstance = axios.create({
  baseURL: API_URL,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

// API service cho sensor data
export const sensorAPI = {
  /**
   * Lấy tất cả dữ liệu cảm biến
   * @param {Object} params - Query parameters {device, limit, from, to}
   * @returns {Promise}
   */
  getAllData: async (params = {}) => {
    try {
      const response = await axiosInstance.get("/sensor-data", { params });
      return response.data;
    } catch (error) {
      console.error("Error fetching all sensor data:", error);
      throw error;
    }
  },

  /**
   * Lấy bản ghi mới nhất
   * @returns {Promise}
   */
  getLatestData: async () => {
    try {
      const response = await axiosInstance.get("/sensor-data/latest");
      return response.data;
    } catch (error) {
      console.error("Error fetching latest sensor data:", error);
      throw error;
    }
  },

  /**
   * Tạo dữ liệu cảm biến mới (dùng cho test)
   * @param {Object|Array} data - Dữ liệu cảm biến
   * @returns {Promise}
   */
  createData: async (data) => {
    try {
      const response = await axiosInstance.post("/sensor-data", data);
      return response.data;
    } catch (error) {
      console.error("Error creating sensor data:", error);
      throw error;
    }
  },

  /**
   * Lấy thống kê (tính toán từ dữ liệu)
   * @returns {Promise}
   */
  getStats: async () => {
    try {
      // Lấy 100 bản ghi gần nhất để tính thống kê
      const response = await axiosInstance.get("/sensor-data", {
        params: { limit: 100 },
      });

      const data = response.data.data || [];

      if (data.length === 0) {
        return {
          totalRecords: 0,
          latestIAQ: 0,
          latestTVOC: 0,
          averageIAQ: 0,
          averageTVOC: 0,
        };
      }

      const latest = data[0]; // Dữ liệu đã sort theo timestamp desc
      const totalRecords = response.data.count || data.length;

      const averageIAQ = Math.floor(
        data.reduce((sum, d) => sum + d.iaq, 0) / data.length
      );

      const averageTVOC = Math.floor(
        data.reduce((sum, d) => sum + d.tvoc, 0) / data.length
      );

      return {
        totalRecords,
        latestIAQ: latest?.iaq || 0,
        latestTVOC: latest?.tvoc || 0,
        averageIAQ,
        averageTVOC,
      };
    } catch (error) {
      console.error("Error fetching stats:", error);
      throw error;
    }
  },
};

export default sensorAPI;
